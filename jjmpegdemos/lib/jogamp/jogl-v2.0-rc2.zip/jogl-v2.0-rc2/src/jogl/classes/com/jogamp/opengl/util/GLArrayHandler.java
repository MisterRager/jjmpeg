
package com.jogamp.opengl.util;

import javax.media.opengl.*;

public interface GLArrayHandler {

  public void enableBuffer(GL gl, boolean enable);

}

