
/** Part of <code>GL_ARB_uniform_buffer_object</code> */
public static final int GL_INVALID_INDEX = 0xFFFFFFFF ;

/** Part of <code>GL_ARB_sync</code> */
public static final long GL_TIMEOUT_IGNORED = 0xFFFFFFFFFFFFFFFFL ;


