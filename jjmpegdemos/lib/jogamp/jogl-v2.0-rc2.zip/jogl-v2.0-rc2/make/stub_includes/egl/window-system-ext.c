#define EGLAPI
#define EGLAPIENTRY

// Define EGL_EGLEXT_PROTOTYPES so that the EGL extension prototypes in
// "eglext.h" are parsed.
#define EGL_EGLEXT_PROTOTYPES

#include <EGL/egl.h>
#include <EGL/eglext.h>
