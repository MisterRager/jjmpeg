// Empty glu.h so that we pick up only the Java routines
