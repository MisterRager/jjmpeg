#ifndef __stdint_h
#define __stdint_h

#include <gluegen_types.h>

#endif /* __stdint_h */

