#ifndef __stddef_h
#define __stddef_h

#include <gluegen_types.h>

#endif /* __stddef_h */
