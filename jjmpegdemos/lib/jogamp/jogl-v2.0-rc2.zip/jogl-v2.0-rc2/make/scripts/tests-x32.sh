#! /bin/bash

spath=`dirname $0`

. $spath/tests.sh  /opt-linux-x86/j2se6/bin/java ../build-x86 $*


