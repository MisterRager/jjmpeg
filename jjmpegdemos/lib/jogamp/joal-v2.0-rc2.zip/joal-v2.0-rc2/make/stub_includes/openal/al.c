#include "al.h"
#define __cdecl
#include "efx.h"
