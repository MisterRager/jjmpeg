
    protected final CLProcAddressTable addressTable;

    public CLAbstractImpl(CLProcAddressTable addressTable) {
        this.addressTable = addressTable;
    }
