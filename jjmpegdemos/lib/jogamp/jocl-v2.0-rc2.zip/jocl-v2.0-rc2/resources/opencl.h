//just to make ANTLR happy
// #define __GNUC__

#include    <CL/cl_platform.h>
#include    <CL/cl.h>
#include    <CL/cl_ext.h>
//#include    <CL/cl_vendor_ext.h>

//#include    <GL/gl.h>
#include    <gltypes.h>
#include    <CL/cl_gl.h>
#include    <CL/cl_gl_ext.h>
